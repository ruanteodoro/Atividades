function calcular() {
    let descricao = document.getElementById("descricao").value;
    let preco = parseFloat(document.getElementById("preco").value);

    if (isNaN(preco)) {
        alert("Digite um preço válido.");
        return;
    }

    let total = preco * 2;

    // pega apenas os centavos
    let centavos = total - Math.floor(total);

    // valor final com desconto dos centavos
    let valorFinal = total - centavos;

    document.getElementById("saidaDescricao").innerText =
        "Promoção de " + descricao;

    document.getElementById("saidaPromocao").innerText =
        "Leve 2 por R$ " + valorFinal.toFixed(2);
}