function calcularPromo() {
    let descricao = document.getElementById("descricao").value;
    let preco = parseFloat(document.getElementById("preco").value);

    if (descricao === "" || isNaN(preco)) {
        document.getElementById("resultado").innerHTML = "Preencha os campos corretamente!";
        return;
    }

    // Um item com 50% de desconto
    let desconto = preco * 0.5;

    // Total para 3 unidades (2 inteiros + 1 com desconto)
    let total = (preco * 2) + desconto;

    document.getElementById("resultado").innerHTML = `
        Produto: ${descricao} <br>
        Promoção: Leve 3 por R$ ${total.toFixed(2)} <br>
        (O 3º produto sai por R$ ${desconto.toFixed(2)})
    `;
}